export interface EthersError extends Error {
  error: Error;
}
